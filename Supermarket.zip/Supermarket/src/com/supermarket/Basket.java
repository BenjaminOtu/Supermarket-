package com.supermarket;

public class Basket {
}
