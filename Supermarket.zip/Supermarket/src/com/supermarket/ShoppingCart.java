package com.supermarket;

public class ShoppingCart {
    public ShoppingCart(){
        System.out.println("Dit is een winkelwagen");
    }
}
